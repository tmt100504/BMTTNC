So = int(input("Nhập vào 1 số nguyên:  " ))
if So % 2 == 0:
      print(So,"là 1 số chẵn")
else:
      print(So,"là 1 số lẽ")