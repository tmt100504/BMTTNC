Ban_Kinh = float(input("Nhập bán kính của đường tròn: "))
Dien_Tich = 3.14 * (Ban_Kinh ** 2)
print("Diện tích của đường tròn là: ",Dien_Tich)