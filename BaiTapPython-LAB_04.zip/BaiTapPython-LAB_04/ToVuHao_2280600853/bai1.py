name = input("nhập tên:")
tuoi = input("Nhập tuổi:")
print("xin chào,",name,"! bạn đã",tuoi,"tuổi.")